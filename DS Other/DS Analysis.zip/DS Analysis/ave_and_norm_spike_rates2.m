function [true_spike_rate, norm_true_spike_rate, spike_rate_all_orientation, Max_Spikes_absolute, max_index] =...
    ave_and_norm_spike_rates2(orientation, all_orientations, num_trials, start_times, end_times, total_spikes)   


